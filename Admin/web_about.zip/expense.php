<?php
$pages = 'expense';
include 'index.php';
