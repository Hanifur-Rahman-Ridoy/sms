<?php
$pages = "data_bank";
include "index.php";