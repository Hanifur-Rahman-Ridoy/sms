<?php
$pages = 'print';
include 'index.php';
