<section class="content">
	<div class="row">





		<div class="col-lg-6 col-12">
			<div class="box">

				<!-- Slider start----------Slider start--------Slider start------------Slider start------------slider -->
				<form class="form">
					<div class="box-body">
						<h4 class="box-title text-info mb-0"><i class="ti-user me-15"></i> Part 1</h4>
						<hr class="my-15">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label class="form-label">Small Status</label>
									<input type="text" class="form-control" value="Crowd founding">
								</div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-label">Big Title part-1</label>
									<input type="text" class="form-control" value="Changer World">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-label">Big Title part-2</label>
									<input type="text" class="form-control" value="Better Future">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<div class="bg-img h-50 w-100" style="background-image: url(images/gallery/studio2.jpg)"></div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-label">Select File</label>
									<label class="file">
										<input type="file" id="file">

									</label>
								</div>
							</div>

						</div>

						<h4 class="box-title text-info mb-0 mt-20"><i class="ti-save me-15"></i> Slider-2</h4>
						<hr class="my-15">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label class="form-label">Small Status</label>
									<input type="text" class="form-control" value="Crowd founding">
								</div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-label">Big Title part-1</label>
									<input type="text" class="form-control" value="Changer World">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-label">Big Title part-2</label>
									<input type="text" class="form-control" value="Better Future">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<div class="bg-img h-50 w-100" style="background-image: url(images/gallery/creative/img-4.jpg)"></div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-label">Select File</label>
									<label class="file">
										<input type="file" id="file">

									</label>
								</div>
							</div>

						</div>
						<h4 class="box-title text-info mb-0 mt-20"><i class="ti-save me-15"></i> Slider-3</h4>
						<hr class="my-15">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label class="form-label">Small Status</label>
									<input type="text" class="form-control" value="Crowd founding">
								</div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-label">Big Title part-1</label>
									<input type="text" class="form-control" value="Changer World">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-label">Big Title part-2</label>
									<input type="text" class="form-control" value="Better Future">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<div class="bg-img h-50 w-100" style="background-image: url(images/gallery/studio1.jpg)"></div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-label">Select File</label>
									<label class="file">
										<input type="file" id="file">

									</label>

								</div>
							</div>

						</div>
					</div>
					<!-- /.box-body -->
					<div class="box-footer">

						<button type="submit" class="btn btn-primary">
							<i class="ti-save-alt"></i> Update
						</button>
						<button type="button" class="btn btn-warning me-1">
							<i class="ti-trash"></i> Cancel
						</button>
					</div>
				</form>
			</div>
			<!-- /.box -->
		</div>

		<!-- Part-2 start----------Part-2 start--------Part-2 start------------Part-2 start------------Part-2 -->

		<hr class="bg-danger" style="height: 4px;">

		<div class="col-12 col-xl-6">
			<div class="box">
				<div class="box-header with-border">
					<h4 class="box-title">Part-2</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label class="form-label">Small Status</label>
								<input type="text" class="form-control" value="Crowd founding">
							</div>
						</div>

					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-1</label>
								<input type="text" class="form-control" value="Changer World">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-2</label>
								<input type="text" class="form-control" value="Better Future">
							</div>
						</div>
						<div class="box-footer">

							<button type="submit" class="btn btn-primary">
								<i class="ti-save-alt"></i> Update
							</button>

						</div>
					</div>


				</div>
				<div class="box-body">
					<div class="media-list media-list-divided">

						<!-- -----------Content Start--------- -->

						<div class="media media-single px-0">
							<img class="w-80 rounded" src="images/gallery/creative/img-1.jpg" alt="...">
							<span class="title fw-500 fs-16">Deeveloper Manual</span>

							<a class="fs-18 text-gray hover-info" href="#" data-bs-toggle="modal" data-bs-target="#add-new-events"><i class="glyphicon glyphicon-pencil text-warning"></i></a>

							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash text-danger"></i></a>

						</div>
						<div class="media media-single px-0">
							<img class="w-80 rounded" src="images/gallery/creative/img-2.jpg" alt="...">
							<span class="title fw-500 fs-16">Deeveloper Manual</span>

							<a class="fs-18 text-gray hover-info" href="#" data-bs-toggle="modal" data-bs-target="#add-new-events"><i class="glyphicon glyphicon-pencil text-warning"></i></a>

							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash text-danger"></i></a>

						</div>
						<div class="media media-single px-0">
							<img class="w-80 rounded" src="images/gallery/creative/img-3.jpg" alt="...">
							<span class="title fw-500 fs-16">Deeveloper Manual</span>

							<a class="fs-18 text-gray hover-info" href="#" data-bs-toggle="modal" data-bs-target="#add-new-events"><i class="glyphicon glyphicon-pencil text-warning"></i></a>

							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash 
                            text-danger"></i></a>
						</div>
						<div class="media media-single px-0">
							<img class="w-80 rounded" src="images/gallery/creative/img-3.jpg" alt="...">
							<span class="title fw-500 fs-16">Deeveloper Manual</span>

							<a class="fs-18 text-gray hover-info" href="#" data-bs-toggle="modal" data-bs-target="#add-new-events"><i class="glyphicon glyphicon-pencil text-warning"></i></a>

							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash 
                            text-danger"></i></a>
						</div>
						<div class="media media-single px-0">
							<img class="w-80 rounded" src="images/gallery/creative/img-3.jpg" alt="...">
							<span class="title fw-500 fs-16">Deeveloper Manual</span>

							<a class="fs-18 text-gray hover-info" href="#" data-bs-toggle="modal" data-bs-target="#add-new-events"><i class="glyphicon glyphicon-pencil text-warning"></i></a>

							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash 
                            text-danger"></i></a>
						</div>
						<!-- -------------content End-------- -->


					</div>
				</div>
			</div>
		</div>

		<!-- Part-3 start----------Part-3 start--------Part-3 start------------Part-3 start------------Part-3 -->

		<hr class="bg-danger" style="height: 4px;">

		<div class="col-12 col-xl-6">
			<div class="box">
				<div class="box-header with-border">
					<h4 class="box-title">Part-3</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label class="form-label">Small Status</label>
								<input type="text" class="form-control" value="Crowd founding">
							</div>
						</div>

					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-1</label>
								<input type="text" class="form-control" value="Changer World">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-2</label>
								<input type="text" class="form-control" value="Better Future">
							</div>
						</div>
						<div class="box-footer">

							<button type="submit" class="btn btn-primary">
								<i class="ti-save-alt"></i> Update
							</button>

						</div>
					</div>


				</div>
				<div class="box-body">
					<div class="media-list media-list-divided">

						<!-- -----------Content Start--------- -->

						<div class="media media-single px-0">
							<img class="w-80 rounded" src="images/gallery/creative/img-1.jpg" alt="...">
							<span class="title fw-500 fs-16">Deeveloper Manual</span>

							<a class="fs-18 text-gray hover-info" href="#" data-bs-toggle="modal" data-bs-target="#add-new-events2"><i class="glyphicon glyphicon-pencil text-warning"></i></a>

							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash text-danger"></i></a>

						</div>
						<div class="media media-single px-0">
							<img class="w-80 rounded" src="images/gallery/creative/img-2.jpg" alt="...">
							<span class="title fw-500 fs-16">Deeveloper Manual</span>

							<a class="fs-18 text-gray hover-info" href="#" data-bs-toggle="modal" data-bs-target="#add-new-events2"><i class="glyphicon glyphicon-pencil text-warning"></i></a>

							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash text-danger"></i></a>

						</div>
						<div class="media media-single px-0">
							<img class="w-80 rounded" src="images/gallery/creative/img-3.jpg" alt="...">
							<span class="title fw-500 fs-16">Deeveloper Manual</span>

							<a class="fs-18 text-gray hover-info" href="#" data-bs-toggle="modal" data-bs-target="#add-new-events"><i class="glyphicon glyphicon-pencil text-warning"></i></a>

							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash 
                            text-danger"></i></a>
						</div>
						<div class="media media-single px-0">
							<img class="w-80 rounded" src="images/gallery/creative/img-3.jpg" alt="...">
							<span class="title fw-500 fs-16">Deeveloper Manual</span>

							<a class="fs-18 text-gray hover-info" href="#" data-bs-toggle="modal" data-bs-target="#add-new-events"><i class="glyphicon glyphicon-pencil text-warning"></i></a>

							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash 
                            text-danger"></i></a>
						</div>

						<!-- -------------content End-------- -->


					</div>
				</div>
			</div>
		</div>

		<!-- Part-4 start----------Part-4 start--------Part-4 start------------Part-4 start------------Part-4 -->

		<hr class="bg-danger" style="height: 4px;">

		<div class="col-12 col-xl-6">
			<div class="box">
				<div class="box-header with-border">
					<h4 class="box-title">Part-4</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label class="form-label">Small Status</label>
								<input type="text" class="form-control" value="Who We Are">
							</div>
						</div>

					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-1</label>
								<input type="text" class="form-control" value="আমাদের 25 বছরের অভিজ্ঞতা">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-2</label>
								<input type="text" class="form-control" value="Crowd Founding এর">
							</div>
						</div>


					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label class="form-label">Members Status</label>
								<input type="text" class="form-control" value="৫০০০ সদস্যের পরিবার">
							</div>
						</div>

					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Title-1</label>
								<input type="text" class="form-control" value="ডোনেশনের টাকার ব্যবহার">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Status-1</label>
								<input type="text" class="form-control" value="কিভাবে টাকাটা ব্যবহার করা হয় তার বিবরণ">
							</div>
						</div>


					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Title-2</label>
								<input type="text" class="form-control" value="Highest Success Rates">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Status-2</label>
								<input type="text" class="form-control" value="কিভাবে আমরা সফলতার সাথে ডোনেশনের টাকা ব্যবহার করি">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label class="form-label">Button Name</label>
									<input type="text" class="form-control" value="যোগাযোগ">
								</div>
							</div>
							<div class="box-footer">

								<button type="submit" class="btn btn-primary">
									<i class="ti-save-alt"></i> Update
								</button>

							</div>

						</div>


					</div>




				</div>

			</div>
		</div>

		<!-- Part-5> start----------Part-5> start--------Part-5> start------------Part-5> start------------Part-5> -->

		<hr class="bg-danger" style="height: 4px;">

		<div class="col-12 col-xl-6">
			<div class="box">
				<div class="box-header with-border">
					<h4 class="box-title">Part-5</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label class="form-label">Small Status</label>
								<input type="text" class="form-control" value="Donate Now">
							</div>
						</div>

					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-1</label>
								<input type="text" class="form-control" value="মানবতার কাজে সাহায্যের হাত বাড়িয়ে দিন">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-2</label>
								<input type="text" class="form-control" value="সঠিক জায়গায়">
							</div>
						</div>


					</div>

					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Button -1</label>
								<input type="text" class="form-control" value="বিস্তারিত জানুন ">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Button -2</label>
								<input type="text" class="form-control" value="donate now">
							</div>
						</div>
						<div class="box-footer">

							<button type="submit" class="btn btn-primary">
								<i class="ti-save-alt"></i> Update
							</button>

						</div>


					</div>





				</div>

			</div>
		</div>


		<!-- Part-6 start----------Part-6 start--------Part-6 start------------Part-6 start------------Part-6 -->
		<hr class="bg-danger" style="height: 4px;">

		<div class="col-12 col-xl-6">
			<div class="box">
				<div class="box-header with-border">
					<h4 class="box-title">Part-6</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label class="form-label">Small Status</label>
								<input type="text" class="form-control" value="Popular Project">
							</div>
						</div>

					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-1</label>
								<input type="text" class="form-control" value="We’ve Done Many Crowd">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-2</label>
								<input type="text" class="form-control" value="Founding Project">
							</div>
						</div>
						<div class="box-footer">

							<button type="submit" class="btn btn-primary">
								<i class="ti-save-alt"></i> Update
							</button>

						</div>
					</div>


				</div>
				<div class="box-body">
					<div class="media-list media-list-divided">

						<!-- -----------Content Start--------- -->

						<div class="media media-single px-0">
							<img class="w-80 rounded" src="images/gallery/creative/img-1.jpg" alt="...">
							<span class="title fw-500 fs-16">ইফতার বিতরণ</span>

							<a class="fs-18 text-gray hover-info" href="#" data-bs-toggle="modal" data-bs-target="#add-new-events2"><i class="glyphicon glyphicon-pencil text-warning"></i></a>

							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash text-danger"></i></a>

						</div>
						<div class="media media-single px-0">
							<img class="w-80 rounded" src="images/gallery/creative/img-2.jpg" alt="...">
							<span class="title fw-500 fs-16">ইফতার বিতরণ</span>

							<a class="fs-18 text-gray hover-info" href="#" data-bs-toggle="modal" data-bs-target="#add-new-events2"><i class="glyphicon glyphicon-pencil text-warning"></i></a>

							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash text-danger"></i></a>

						</div>
						<div class="media media-single px-0">
							<img class="w-80 rounded" src="images/gallery/creative/img-3.jpg" alt="...">
							<span class="title fw-500 fs-16">ইফতার বিতরণ</span>

							<a class="fs-18 text-gray hover-info" href="#" data-bs-toggle="modal" data-bs-target="#add-new-events"><i class="glyphicon glyphicon-pencil text-warning"></i></a>

							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash 
                            text-danger"></i></a>
						</div>


						<!-- -------------content End-------- -->


					</div>
				</div>
			</div>
		</div>

		<!-- Part-7 start----------Part-7 start--------Part-7 start------------Part-7 start------------Part-7 -->

		<hr class="bg-danger" style="height: 4px;">

		<div class="col-12 col-xl-6">
			<div class="box">
				<div class="box-header with-border">
					<h4 class="box-title">Part-7</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label class="form-label">Small Status</label>
								<input type="text" class="form-control" value="Newsletters">
							</div>
						</div>

					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-1</label>
								<input type="text" class="form-control" value="Join Today">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-2</label>
								<input type="text" class="form-control" value="Joining Request Sent">
							</div>
						</div>


					</div>

					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">input Status</label>
								<input type="text" class="form-control" value="মানবতার সেবায় যোগ দিন ">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Placeholder</label>
								<input type="text" class="form-control" value="নাম্বার অথবা ই-মেইল দিন">
							</div>
						</div>
						<div class="box-footer">

							<button type="submit" class="btn btn-primary">
								<i class="ti-save-alt"></i> Update
							</button>

						</div>


					</div>





				</div>

			</div>
		</div>


		<!-- Part-8 start----------Part-8 start--------Part-8 start------------Part-8 start------------Part8 -->
		<hr class="bg-danger" style="height: 4px;">
		<div class="col-12 col-xl-6">
			<div class="box">
				<div class="box-header with-border">
					<h4 class="box-title">Introduction</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label class="form-label">Small Status</label>
								<input type="text" class="form-control" value="Feedback">
							</div>
						</div>

					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-1</label>
								<input type="text" class="form-control" value="35675+ Peoples Say">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Big Title part-2</label>
								<input type="text" class="form-control" value="About SMS Sosity">
							</div>
						</div>
						<div class="box-footer">

							<button type="submit" class="btn btn-primary">
								<i class="ti-save-alt"></i> Update
							</button>

						</div>


					</div>






				</div>

			</div>
		</div>
		<div class="col-lg-6 col-12">
			<div class="box">
				<div class="box-header with-border">
					<h4 class="box-title">Add New Review</h4>
				</div>
				<!-- /.box-header -->
				<form class="form">
					<div class="box-body">
						<h4 class="box-title text-info mb-0"><i class="ti-user me-15"></i>Donner Review</h4>
						<hr class="my-15">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-label">Name</label>
									<input type="text" class="form-control" placeholder="First Name">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-label">Position</label>
									<input type="text" class="form-control" placeholder="Last Name">
								</div>
							</div>
						</div>



						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-label">Select Image</label>
									<label class="file">
										<input type="file" id="file">
									</label>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-label">Rating Stars</label>
									<select class="form-select">
										<option>---Select---</option>
										<option>1 star </option>
										<option>2 star</option>
										<option>3 star</option>
										<option>4 star</option>
										<option>5 star</option>

									</select>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="form-label">Short Description</label>
							<textarea rows="5" class="form-control" placeholder="About Project"></textarea>
						</div>
					</div>
					<!-- /.box-body -->
					<div class="box-footer">

						<button type="submit" class="btn btn-primary">
							<i class="ti-save-alt"></i> Add+
						</button>
					</div>
				</form>
			</div>
			<!-- /.box -->
		</div>


		<div class="col-md-6 col-12">
			<div class="media bg-white mb-20">
				<span class="avatar status-success">
					<img class="avatar" src="images/avatar.png" alt="...">
				</span>
				<div class="media-body">
					<p><strong>David Michel</strong> <time class="float-end" datetime="2017-07-14 20:00">CEO &
							Founder</time></p>
					<p>But I must explain to you how all this mistake
						denouncing
						pleasure and praising pain was born and I will give you a complete account of
						the
						system, and expound the actual teachings of the great explorer of ter-builder
					</p>
					<div class="d-inline-block pull-left mt-10">
						<button type="button" class="btn btn-rounded btn-sm btn-success m-5">4 Stars</button>
						<button type="button" class="btn btn-rounded btn-sm btn-danger m-5">Delete</button>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-6 col-12">
			<div class="media bg-white mb-20">
				<span class="avatar status-success">
					<img class="avatar" src="images/avatar.png" alt="...">
				</span>
				<div class="media-body">
					<p><strong>David Michel</strong> <time class="float-end" datetime="2017-07-14 20:00">CEO &
							Founder</time></p>
					<p>But I must explain to you how all this mistake
						denouncing
						pleasure and praising pain was born and I will give you a complete account of
						the
						system, and expound the actual teachings of the great explorer of ter-builder
					</p>
					<div class="d-inline-block pull-left mt-10">
						<button type="button" class="btn btn-rounded btn-sm btn-success m-5">4 Stars</button>
						<button type="button" class="btn btn-rounded btn-sm btn-danger m-5">Delete</button>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-6 col-12">
			<div class="media bg-white mb-20">
				<span class="avatar status-success">
					<img class="avatar" src="images/avatar.png" alt="...">
				</span>
				<div class="media-body">
					<p><strong>David Michel</strong> <time class="float-end" datetime="2017-07-14 20:00">CEO &
							Founder</time></p>
					<p>But I must explain to you how all this mistake
						denouncing
						pleasure and praising pain was born and I will give you a complete account of
						the
						system, and expound the actual teachings of the great explorer of ter-builder
					</p>
					<div class="d-inline-block pull-left mt-10">
						<button type="button" class="btn btn-rounded btn-sm btn-success m-5">4 Stars</button>
						<button type="button" class="btn btn-rounded btn-sm btn-danger m-5">Delete</button>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-6 col-12">
			<div class="media bg-white mb-20">
				<span class="avatar status-success">
					<img class="avatar" src="images/avatar.png" alt="...">
				</span>
				<div class="media-body">
					<p><strong>David Michel</strong> <time class="float-end" datetime="2017-07-14 20:00">CEO &
							Founder</time></p>
					<p>But I must explain to you how all this mistake
						denouncing
						pleasure and praising pain was born and I will give you a complete account of
						the
						system, and expound the actual teachings of the great explorer of ter-builder
					</p>
					<div class="d-inline-block pull-left mt-10">
						<button type="button" class="btn btn-rounded btn-sm btn-success m-5">4 Stars</button>
						<button type="button" class="btn btn-rounded btn-sm btn-danger m-5">Delete</button>
					</div>
				</div>
			</div>
		</div>

		<!-- Part-9 start----------Part-9 start--------Part-9 start------------Part-9 start------------Part-9-->
		<hr class="bg-danger" style="height: 4px;">

		<div class="col-12 col-xl-6">
			<div class="box">
				<div class="box-header with-border">
					<h4 class="box-title">Part-6 [Sponsor Logo]</h4>
					<div class="row">


					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Select Image</label>
								<label class="file">
									<input type="file" id="file">
								</label>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label class="form-label">Small Status</label>
								<input type="text" class="form-control" value="Popular Project">
							</div>
						</div>
						<div class="box-footer">

							<button type="submit" class="btn btn-primary">
								<i class="ti-save-alt"></i> Add+
							</button>
						</div>
					</div>


				</div>
				<div class="box-body">
					<div class="media-list media-list-divided">

						<!-- -----------Content Start--------- -->

						<div class="media media-single px-0">
							<img class="w-150 h-50 rounded" src="images/gallery/creative/img-1.jpg" alt="...">



							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash text-danger"></i></a>

						</div>
						<div class="media media-single px-0">
							<img class="w-150 h-50 rounded" src="images/gallery/creative/img-1.jpg" alt="...">



							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash text-danger"></i></a>

						</div>
						<div class="media media-single px-0">
							<img class="w-150 h-50 rounded" src="images/gallery/creative/img-1.jpg" alt="...">



							<a class="fs-18 text-gray hover-info" href="#"><i class="glyphicon glyphicon-trash text-danger"></i></a>

						</div>




						<!-- -------------content End-------- -->


					</div>
				</div>
			</div>
		</div>


































	</div>
</section>









<!-- ---------------model part-2------------ -->

<div class="modal fade none-border" id="add-new-events">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title"><strong>Add</strong> a category</h4>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<form role="form">
					<div class="row">
						<div class="col-md-6">
							<label class="form-label">Image Title</label>
							<input type="text" class="form-control" placeholder="First Name">
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="form-label">Position <span class="text-danger">*</span></label>
								<select class="form-select">
									<option>--- Select ONE ---</option>
									<option value="flaticon-dish">Dish</option>
									<option value="flaticon-24-hours-support">24 Hours Support</option>
									<option value="flaticon-email">Email</option>
									<option value="flaticon-computer">Computer</option>
									<option value="flaticon-crowdfunding-1">Crowdfunding-1</option>
									<option value="flaticon-heart-1">Heart-1</option>
									<option value="flaticon-high-performance">High Performance</option>
									<option value="flaticon-investment">Investment</option>
									<option value="flaticon-open-book">Open Book</option>
									<option value="flaticon-project-management">Project Management</option>
									<option value="flaticon-right-quote">Right Quote</option>
									<option value="flaticon-stethoscope">Stethoscope</option>
									<option value="flaticon-vector">Vector</option>

								</select>
							</div>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<a type="button" class="btn btn-info save-category" data-bs-dismiss="modal">Update</a>
				<a type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</a>
			</div>
		</div>
	</div>
</div>
<!-- ---------------model part-3 start------------ -->

<div class="modal fade none-border" id="add-new-events2">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title"><strong>Add</strong> a category</h4>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<form role="form">
					<div class="row">
						<div class="col-md-6">
							<label class="form-label">Title</label>
							<input type="text" class="form-control" placeholder="First Name">
						</div>

						<div class="form-group mt-2">
							<label class="form-label">Select File</label>
							<label class="file">
								<input type="file" id="file">
							</label>
						</div>
						<div class="form-group">
							<label class="form-label">Small Status</label>
							<textarea rows="5" class="form-control" placeholder="About Project"></textarea>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<a type="button" class="btn btn-info save-category" data-bs-dismiss="modal">Update</a>
				<a type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</a>
			</div>
		</div>
	</div>
</div>