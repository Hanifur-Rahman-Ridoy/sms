<section class="content">
    <div class="row">
        <div class="col-lg-6 col-12 ">
            <div class="box ">

                <!-- /.box-header -->
                <form class="form" action="" method="POST">
                    <div class="box-body">
                        <h4 class="box-title text-info mb-0"><i class="ti-user me-15"></i> Personal Info</h4>
                        <hr class="my-15">
                        <div class="row">
                            <div class="col-md-3 col-3">

                                <label class="form-label">Name : </label>

                                <!-- /.form-group -->
                            </div>
                            <div class="col-md-9 col-9">
                                <div class="form-group">

                                    <select class="form-control select2" style="width: 100%;">
                                        <option selected="selected">Hanifur Rahman</option>
                                        <option>Raihan</option>
                                        <option>alif</option>
                                        <option>Hamidur Rahman</option>
                                        <option>Amili</option>
                                        <option>Afsana</option>
                                        <option>joy</option>
                                    </select>
                                </div>
                                <!-- /.form-group -->
                            </div>

                        </div>



                        <div class="row">
                            <div class="form-group">

                                <div class="row ">
                                    <div class="col-6">

                                        <div class="input-group ">

                                            <input type="text" class="form-control text-center" placeholder="Fathers Name" value="Habibur Rahman" readonly>
                                        </div>

                                        <!-- /.input group -->
                                    </div>
                                    <div class="col-6">

                                        <!-- Date mm/dd/yyyy -->
                                        <div class="input-group">

                                            <input type="text" class="form-control text-center" placeholder="Fathers Name" value="Umme jaimun" readonly>
                                        </div>

                                        <!-- /.input group -->
                                    </div>
                                </div>
                            </div>
                        </div>




                        <div class="row">
                            <div class="col-md-3 col-3">

                                <label class="form-label">Amount : </label>

                                <!-- /.form-group -->
                            </div>
                            <div class="col-md-9 col-9">
                                <div class="form-group row">

                                    <div class="col-sm-12">
                                        <input class="form-control" type="month" value="2022-08">
                                    </div>
                                </div>
                            </div>
                            <!-- /.form-group -->
                        </div>

                        <div class="row">
                            <div class="col-md-3 col-3">

                                <label class="form-label">Amount : </label>

                                <!-- /.form-group -->
                            </div>
                            <div class="col-md-9 col-9">
                                <div class="form-group">

                                    <input id="demo2" type="text" name="demo2" class=" form-control" data-bts-button-down-class="btn btn-secondary" data-bts-button-up-class="btn btn-secondary">
                                </div>
                            </div>
                            <!-- /.form-group -->
                        </div>

                    </div>





            </div>
            <!-- /.box-body -->
            <div class="box-footer">
                <button type="button" class="btn btn-warning me-1">
                    <i class="ti-trash"></i> Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="ti-save-alt"></i> Save
                </button>
            </div>
            </form>

        </div>
        <!-- /.box -->
    </div>




    </div>
    <!--/.col (left) -->
    <!-- right column -->

    <!--/.col (right) -->
    </div>
    <!-- /.row -->

</section>