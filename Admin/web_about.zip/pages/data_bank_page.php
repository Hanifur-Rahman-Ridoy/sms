<section class="content">
    <div class="row">

        <div class="col-12">
            <div class="box">
                <div class="box-header ">

                    <h6 class="box-title">Total Members: <span class="text-success bold"> 20</span></h6>


                </div>
                <div class="box-body">
                    <div class="table-responsive">
                        <table id="complex_header" class="table table-striped table-hover table-bordered display" style="width:100%">
                            <thead class="table-primary bg-primary">

                                <tr>
                                    <th>AC NO</th>
                                    <th>Name</th>
                                    <th>Number</th>
                                    <th>status</th>
                                    <th hidden>Gender</th>
                                    <th>Position</th>
                                    <th>Email</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>






                                <tr>
                                    <td><a href="user_profile.php" class="">#11111</a></td>
                                    <td>Hanifur Rahman</td>
                                    <td>01790370183</td>
                                    <td hidden>male</td>
                                    <td>member</td>
                                    <td>manager</td>
                                    <td>hrridoy90@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="user_profile.php" class="">#22222</a></td>
                                    <td>Ramisa</td>
                                    <td>01376355432</td>
                                    <td hidden>Female</td>
                                    <td>Donner</td>
                                    <td>member</td>
                                    <td>hrr90@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="user_profile.php" class="">#28712</a></td>
                                    <td>Atikur Rahman</td>
                                    <td>01790370183</td>
                                    <td hidden>male</td>
                                    <td>member</td>
                                    <td>member</td>
                                    <td>hrridoy90@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="user_profile.php" class="">#28712</a></td>
                                    <td>Anika</td>
                                    <td>01790370183</td>
                                    <td hidden>female</td>
                                    <td>member</td>
                                    <td>advisor</td>
                                    <td>raihan@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="user_profile.php" class="">#28712</a></td>
                                    <td>nimisa</td>
                                    <td>01790370183</td>
                                    <td hidden>female</td>
                                    <td>member</td>
                                    <td>manager</td>
                                    <td>hrridoy90@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="user_profile.php" class="">#28712</a></td>
                                    <td>Hanifur Rahman</td>
                                    <td>01790370183</td>
                                    <td hidden>male</td>
                                    <td>member</td>
                                    <td>manager</td>
                                    <td>hrr90@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="user_profile.php" class="">#28712</a></td>
                                    <td>Atikur Rahman</td>
                                    <td>01790370183</td>
                                    <td hidden>male</td>
                                    <td>member</td>
                                    <td>member</td>
                                    <td>hrridoy90@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="user_profile.php" class="">#28712</a></td>
                                    <td>Rohim uddin</td>
                                    <td>01790370183</td>
                                    <td hidden>male</td>
                                    <td>member</td>
                                    <td>donner</td>
                                    <td>hrridoy90@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="user_profile.php" class="">#28712</a></td>
                                    <td>Hanifur Rahman</td>
                                    <td>01790370183</td>
                                    <td hidden>male</td>
                                    <td>member</td>
                                    <td>manager</td>
                                    <td>hrridoy90@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="user_profile.php" class="">#28712</a></td>
                                    <td>Hanifur Rahman</td>
                                    <td>01790370183</td>
                                    <td hidden>male</td>
                                    <td>member</td>
                                    <td>manager</td>
                                    <td>hrr90@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="user_profile.php" class="">#28712</a></td>
                                    <td>Atikur Rahman</td>
                                    <td>01790370183</td>
                                    <td hidden>male</td>
                                    <td>member</td>
                                    <td>member</td>
                                    <td>hrridoy90@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="user_profile.php" class="">#28712</a></td>
                                    <td>Rohim uddin</td>
                                    <td>01790370183</td>
                                    <td hidden>male</td>
                                    <td>member</td>
                                    <td>donner</td>
                                    <td>hrridoy90@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="user_profile.php" class="">#28712</a></td>
                                    <td>Hanifur Rahman</td>
                                    <td>01790370183</td>
                                    <td hidden>male</td>
                                    <td>member</td>
                                    <td>manager</td>
                                    <td>hrridoy90@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><a href="user_profile.php" class="">#28712</a></td>
                                    <td>Hanifur Rahman</td>
                                    <td>01790370183</td>
                                    <td hidden>male</td>
                                    <td>member</td>
                                    <td>manager</td>
                                    <td>hrr90@gmail.com</td>
                                    <td class="text-center m-0 p-0">
                                        <table class="table m-1 p-0">
                                            <tr>
                                                <td class="bg-success-light hr-p1"> <a href="add_member.php" class="hr"><span class="glyphicon glyphicon-pencil text-dark  "></span></a></td>
                                                <td class="bg-lightest hr-p1 "> <a href="#" class="hr"><span class="glyphicon glyphicon-trash text-danger"></span></td></a>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
















                            </tbody>
                            <!-- <tfoot>

                                <tr>
                                    <th>Name</th>
                                    <th>Name</th>
                                    <th>Position</th>
                                    <th>Salary</th>
                                    <th>Office</th>
                                    <th>Extn.</th>
                                    <th>Extn.</th>

                                </tr>
                            </tfoot> -->
                        </table>
                    </div>
                </div>
            </div>
        </div>






        <!-- /.box -->
    </div>
    <!-- /.col -->
    </div>
    <!-- /.row -->
</section>