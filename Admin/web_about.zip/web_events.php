<?php
$pages = 'web_events';
include 'index.php';