<?php
$pages = 'web_home';
include 'index.php';