<?php
$pages = 'user_profile';
include 'index.php';
