<?php
$pages = 'web_contact';
include 'index.php';
