<?php
$pages = "add_fee";
include "index.php";
