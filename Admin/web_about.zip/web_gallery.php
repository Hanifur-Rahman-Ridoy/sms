<?php
$pages = 'web_gallery';
include 'index.php';