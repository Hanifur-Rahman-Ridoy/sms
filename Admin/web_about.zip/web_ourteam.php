<?php
$pages = 'web_ourteam';
include 'index.php';