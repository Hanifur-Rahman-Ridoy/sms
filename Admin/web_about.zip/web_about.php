<?php
$pages = 'web_about';
include 'index.php';