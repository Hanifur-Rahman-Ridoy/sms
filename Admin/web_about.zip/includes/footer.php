<footer class="main-footer">
	<div class="container">
		<div class="pull-right d-none d-sm-inline-block">
			<ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
				<li class="nav-item">
					<a class="nav-link" href="javascript:void(0)">FAQ</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="https://hanifur-rahman-ridoy.github.io/My-Portfolio/?fbclid=IwAR3r2GXzUPupcNbf8wpMHT9KFeW4lrVuGj63F7CxuiY5DzKpcDYYbnd7L-M">About Us</a>
				</li>
			</ul>
		</div>
		&copy; 2022 <a href="https://www.facebook.com/hrsofttech.ltd">HR SoftTech</a>. All Rights Reserved.
	</div>
</footer>