<?php
$pages = 'web_gallery_edit';
include 'index.php';
